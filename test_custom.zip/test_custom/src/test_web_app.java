import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import ryanairrepository.homepage;
import ryanairrepository.loginPage;

import java.util.concurrent.TimeUnit;

public class test_web_app {
    @BeforeClass
    public static void setup() {
        System.setProperty("webdriver.chrome.driver", "/home/ute/Documents/Work/Develop/Python/webdriver_my/chromedriver");
        WebDriver driver = new ChromeDriver();

        //       driver.manage().deleteAllCookies();
        //       driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30,
                TimeUnit.SECONDS);
    }

    @Test(priority = 1)
    public void Login() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.ryanair.com/ie/en/");
        JavascriptExecutor js = (JavascriptExecutor) driver;
        loginPage lp = new loginPage(driver);
        lp.Login().click();
        Thread.sleep(500);
        lp.EmailId().click();
        lp.EmailId().sendKeys("gora2ks@gmail.com");
        lp.Eye().click();
        lp.PasswordId().sendKeys("Gogodz78600");
        lp.SubmitId().click();
        {
            homepage hp = new homepage(driver);
        hp.departure().click();

        }
    }

//        WebElement overlay = driver.findElement(By.xpath(".//input[@name='password']"));
//        js.executeScript("arguments[0].click();", overlay);;
//        overlay.sendKeys("123");
//        System.out.printf(" go");
//        lp.SubmitId().click();


//        Assert.assertTrue(driver.findElement(By.cssSelector("#checkBoxOption1")).isSelected());
//        Assert.assertFalse(driver.findElement(By.cssSelector("#checkBoxOption1")).isSelected())



//    @Test(priority = 3)
//    void homepage() {
//        WebDriver driver = new ChromeDriver();
//        homepage hp = new homepage(driver);
//
//
//
//        System.out.printf("gogodz");
//    }

    @Test(priority = 1)
    void pay() {
        int apple = 5;
        System.out.println(apple + 3.5);


    }

}

