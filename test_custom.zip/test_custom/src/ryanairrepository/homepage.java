package ryanairrepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class homepage {
    WebDriver driver;

    // Home Page class implemented in Page object factory method
    public homepage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    //Departure
    @FindBy(css = "input[placeholder='Departure airport']")
 //   @FindBy(xpath = "//div[@placeholder='Departure airport']//div[@class='field-type']//div[@class='field-value']//div//div[@class='disabled-overlay']")
    WebElement departure;

    //Destination
    @FindBy(css = "input[placeholder='Departure airport']")
//    @FindBy(xpath = ".//*[@placeholder='Departure airport'] ")
            WebElement destination;

    public WebElement destination()
    {
        return destination;
    }

    public WebElement departure()
    {
        return departure;
    }

//    public WebElement Departure() {
//        return driver.findElement(destination);
//    }
//
//    public WebElement Destination() {
//        return driver.findElement(departure);
    }



